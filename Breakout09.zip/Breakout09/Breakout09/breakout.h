// file: Breakout.cpp
// by: Ben Heins
// org: 2001, 202101, 10409
// desc: main configuration header for 2D Breakout game
// ----------------------------------------------------
#ifndef BREAKOUT_H
#define BREAKOUT_H

#include <string>	// for window title

// Global constants 
//-----------------------------------------------------

//main game window properties
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;
const std::string WINDOW_TITLE = "Breakout";

// game settings
const double FRAME_RATE = 1.0 / 60.0;

// flag values

enum Direction {
	DIR_EXIT = -1,
	DIR_NONE,
	DIR_UP,
	DIR_DOWN,
	DIR_LEFT,
	DIR_RIGHT
};

enum CollisionType {
	COLLISION_NONE,			// 0b00
	COLLISION_VERTICAL,		// 0b01
	COLLISION_HORIZONTAL	// 0b10
};

//game components

//ball properties
const int BALL_SIZE = 8; //radius of ball in pixels
const int BALL_COLOR = fgcugl::Orange;
const float BALL_SPEED_X = 2.0; //incremental speed horizontally in pixels
const float BALL_SPEED_Y = 2.0; //incremental speed vertically in pixels

struct Ball {
	float xpos;
	float ypos;
	float velocityX;
	float velocityY;
	int radius = BALL_SIZE;
};

// Border walls
const int WALL_SIZE = 2;

// breakout blocks and walls
struct Block {
	int xpos;
	int ypos;
	int width;
	int height;
};

// border walls
struct Walls {
	Block top;
	Block bottom;
	Block left;
	Block right;

};
#endif //BREAKOUT_H