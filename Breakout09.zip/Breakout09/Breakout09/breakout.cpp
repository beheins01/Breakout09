// file: Breakout.cpp
// lab: 9
// by: Ben Heins
// org: 2001, 202101, 10409
// desc: main application file for 2D Breakout game
// ----------------------------------------------------
#include <iostream> // console library for debugging
#define _USE_MATH_DEFINES	//enable M_PI
#include <math.h>	// sqrt, pow, atan2, M_PI

#include "fgcugl.h"		// fgcu OpenGl library
#include "breakout.h"	// main application header file

// function prototype
Direction processInput();
bool update(Ball& ball, Walls walls, double lag, Direction next);
void render(Ball ball, Walls walls, double lag);
CollisionType collisionCheck(Ball ball, Block block);


int main()
{
	//main game window
	fgcugl::openWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, false);

	// border walls
	Walls walls;
	walls.top = { 0, WINDOW_HEIGHT - WALL_SIZE, WINDOW_WIDTH, WALL_SIZE };
	walls.bottom = { 0, 0, WINDOW_WIDTH, WALL_SIZE };
	walls.left = { 0, 0, WALL_SIZE, WINDOW_HEIGHT };
	walls.right = { WINDOW_WIDTH - WALL_SIZE, 0, WALL_SIZE, WINDOW_HEIGHT };

	//create the ball
	Ball ball = { WINDOW_WIDTH / 2.0, WINDOW_HEIGHT / 2.0, 0.0, 0.0 };

	// directions
	Direction currentDirection = DIR_NONE, nextDirection = DIR_NONE;

	// timing for our game loop
	double startTime = fgcugl::getTime();
	double finishTime = 0.0, deltaTime = 0.0;


	//main game loop
	bool gameover = false;
	while (!gameover)
	{
		finishTime = fgcugl::getTime();			// stop frame timer
		deltaTime += finishTime - startTime;	// add current lag
		startTime = finishTime;

		// processInput
		nextDirection = processInput();

		// update
		while (deltaTime >= FRAME_RATE)
		{
			gameover = update(ball, walls, deltaTime, nextDirection);
			deltaTime -= FRAME_RATE;
		}

		
		// render
		render(ball, walls, deltaTime);

		//get keyboard and window move/close events
		fgcugl::getEvents();

		//end game if window closed
		gameover = gameover || fgcugl::windowClosing();
	}// end game loop

	return 0;
} //end of main

/**
 get user keyboard input

 Parameters:

 Returns:
 Direction	next direction to move (default DIR_NONE)

*/
Direction processInput()
{
	Direction direction = DIR_NONE;

	char key = fgcugl::getKey();

	//get keyboard input
	switch (key)
	{
	case 'W': //up
		direction = DIR_UP;
		break;
	case 'S': //down
		direction = DIR_DOWN;
		break;
	case 'A': //left
		direction = DIR_LEFT;
		break;
	case 'D': //right
		direction = DIR_RIGHT;
		break;
	case 'X': //exit
		direction = DIR_EXIT;
	}

	return direction;
}	// end processInput



/*
* Update game object
* Parameters:
* ball				location and speed of the ball
* walls				border walls for collision checks
* lag				current frame time plus lag
* next				next direction to move the ball
*
* Returns:
* bool		ture if game should end
*/
bool update(Ball& ball, Walls walls, double lag, Direction next)
{
	bool quit = false;

	switch (next)
	{
	case DIR_UP:
		ball.velocityY += BALL_SPEED_Y;
		break;
	case DIR_DOWN:
		ball.velocityY -= BALL_SPEED_Y;
		break;
	case DIR_LEFT:
		ball.velocityX -= BALL_SPEED_X;
		break;
	case DIR_RIGHT: 
		ball.velocityX += BALL_SPEED_X;
		break;
	case DIR_EXIT:
		quit = true;
	}
	


	//adjust ball to new position based on speed
	ball.xpos += ball.velocityX * lag;
	ball.ypos += ball.velocityY * lag;

	// see if ball has hit a wall
	int collision = collisionCheck(ball, walls.top);
	collision |= collisionCheck(ball, walls.bottom);
	collision |= collisionCheck(ball, walls.left);
	collision |= collisionCheck(ball, walls.right);

	if (collision)
	{

		// for a collision we invert the velocities and then move the ball half of its radius
		// in the new direction to get it out of the object it is colliding wit, so we don't
		// end up with a 2nd collision on the next update

		if (collision & COLLISION_VERTICAL)
		{
			ball.velocityY *= -1;		// invert vertical velocity
			ball.ypos += (ball.velocityY > 0.0 ? 1 : -1) * (BALL_SIZE + 1);		// move ball out of object by radius + 1
		}

		if (collision & COLLISION_HORIZONTAL)
		{
			ball.velocityX *= -1;		// invert vertical velocity
			ball.xpos += (ball.velocityX > 0.0 ? 1 : -1) * (BALL_SIZE + 1);		// move ball out of object by radius + 1
		}

	} // had a collision

	return quit;
} // end update

bool update()
{
	return false;
}

/**
* draw game objects on the OpenGL window
*
* Parameters:
* ball				location and speed of the ball
* walls				border walls for collision checks
* lag				build up of lag between frames
*
* Returns:
* void
*/
void render(Ball ball, Walls walls, double lag)
{

	//draw ball in new position relative to current lag
	ball.xpos += ball.velocityX * lag;
	ball.ypos += ball.velocityY * lag;
	fgcugl::drawCircle(ball.xpos, ball.ypos, BALL_SIZE, BALL_COLOR);

	// draw walls
	fgcugl::drawQuad(walls.top.xpos, walls.top.ypos, walls.top.width, walls.top.height);
	fgcugl::drawQuad(walls.bottom.xpos, walls.bottom.ypos, walls.bottom.width, walls.bottom.height);
	fgcugl::drawQuad(walls.left.xpos, walls.left.ypos, walls.left.width, walls.left.height);
	fgcugl::drawQuad(walls.right.xpos, walls.right.ypos, walls.right.width, walls.right.height);

	// paint new scene to window
	fgcugl::windowPaint();
} //end render

/*
* check for collisions between a circle and a rectangle
*
* Parameters:
* ball			the location and size of the ball
* block			the location and size of block to check
*
* Returns:
* int	collision in the vertical, horizontal, or none
*/

CollisionType collisionCheck(Ball ball, Block block)
{
	CollisionType quadrant = COLLISION_NONE;

	// coordinates on the rectangle closest to the circle center
	float testX = ball.xpos;	// circle X between rectangle X and rectangle X + width
	float testY = ball.ypos;	// circle Y between rectangle Y and rectangle Y + height

	// find horizontal coordinate on the rectangle closest to circle center
	if (ball.xpos < block.xpos)		// cirlce left of rectangle
	{
		testX = block.xpos;
	}
	else if (ball.xpos > block.xpos + block.width) // circle right of the rectangle
	{
		testX = block.xpos + block.width;
	}

	// find vertical coordinate on the rectangle closest to circle center
	if (ball.ypos < block.ypos)		// cirlce left of rectangle
	{
		testY = block.ypos;
	}
	else if (ball.ypos > block.ypos + block.height) // circle right of the rectangle
	{
		testX = block.ypos + block.height;
	}

	// calc difference between circle and rectangle (x,y) coordinates
	float diffX = testX - ball.xpos;
	float diffY = testY - ball.ypos;

	// calc distance from circle center to rectangle using Pythagorean Theorem
	float distance = std::sqrt(pow(diffX, 2) + pow(diffY, 2));

	// if circle is closer to rectangle then its radius
	// then we had a collison
	if (distance < ball.radius)
	{

		float radians = std::atan2(diffY, diffX);
		float angle = radians * 180.0 / M_PI;		// relative to X-axis
		float degrees = 90.0 - angle;					// rotate angle to left 90 degrees
		float cardnial = int(degrees > 0.0 ? degrees : degrees + 360.0);		// fix negative cardnial

		// we are dividing the ball into 45 degree quadrants with the upper and lower
		// resulting in a vertical collision, and the left and right a horizontal collision

		// most of our collsion will be vertical, so we will make
		// the 45 degree redials inclusive in the vertical checks
		if ((cardnial >= 315 || cardnial <= 45) ||		// top quadrant
			(cardnial >= 135 && cardnial <= 225))		// bottom quadrant
		{
			quadrant = COLLISION_VERTICAL;
		}
		else                                            // left or right quadrant
		{
			quadrant = COLLISION_HORIZONTAL;
		} //  quadrants

	} // end collsion

	return quadrant;
}