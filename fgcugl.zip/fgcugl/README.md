# fgcugl
OpenGL wrapper library for Programming Methodology course work

Library was built on OpenGL using SDK libraries:
- GLEW 2.1.0 (https://www.opengl.org/sdk/libs/GLEW/)
- GLFW 3.3.2 (https://www.glfw.org/)
